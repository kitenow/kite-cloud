"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const serverlessExpress = require("aws-serverless-express");
const app_1 = require("./app");
const server = serverlessExpress.createServer(app_1.app);
const handler = (event, context) => {
    console.log("asdasd");
    serverlessExpress.proxy(server, event, context);
};
exports.handler = handler;
