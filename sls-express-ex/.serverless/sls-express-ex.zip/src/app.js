"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const express = require("express");
const app = express();
exports.app = app;
app.get("/hello", (req, res, next) => {
    return res.status(200).json({
        message: "Hello, World!",
    });
});
app.get("/error", (req, res, next) => {
    const err = new Error();
    return next(err);
});
app.use((req, res, next) => {
    return res.status(404).json({
        message: "Not Found",
    });
});
app.use(((err, req, res, next) => {
    return res.status(500).json({
        message: "Internal Server Error",
    });
}));
